package spring.biz.admin.dao;

import java.util.List;

import spring.biz.studyroom.vo.StudyRoomVO;
import spring.biz.user.vo.UserVO;

public interface AdminDAO {
	List<UserVO> getUserList();
	
	List<StudyRoomVO> getStudyRoomList();

	List<UserVO> searchUser(String condition,String keyword);
	
	List<StudyRoomVO> searchStudyRoom(String condition,String keyword);
	/*
	 * UserVO login(String id,String pw);
	 * 
	 * int addUser(UserVO user);
	 * 
	 * UserVO getUser(String userid);
	 * 
	 * List<UserVO> getUserList();
	 * 
	 * int updateUser(UserVO user);
	 * 
	 * int removeUser(String userid);
	 * 
	 * List<UserVO> searchUser(String condition,String keyword);
	 */
}
