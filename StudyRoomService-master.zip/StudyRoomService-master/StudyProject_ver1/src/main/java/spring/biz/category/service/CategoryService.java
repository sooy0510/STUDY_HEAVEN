package spring.biz.category.service;

import java.util.List;

import spring.biz.category.vo.CategoryVO;

public interface CategoryService {
	List<CategoryVO> getCategoryList();
}
